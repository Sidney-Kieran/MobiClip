<?php
session_start();
include "../functions/conn.php";
include "../functions/DAO/cartDAO.php";
include "../functions/entities/category.php";
include "../functions/DAO/categoryDAO.php";
include "../functions/entities/product.php";
include "../functions/DAO/productDAO.php";
?>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>MOBICLIP | Register</title>
    <link rel="icon" href="../images/logo_small.png">
    <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Open+Sans" />
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <style>
        main{
            margin-top: 50px;
        }
    </style>
</head>
<body>
<?php
$page = $_SERVER['PHP_SELF'];
include '../includes/modals.php';?>
<?php include '../includes/header.php'; ?>
<main>
    <div class="container">
        <div class="row">
            <?php
            if (isset($_GET['view'])){
                include '../includes/productView.php';
            }
            ?>
        </div>
    </div>
</main>
<?php include "../includes/footer.php";?>
</body>
<script type="text/javascript" src="../js/jquery-3.1.0.min.js"></script>
<script type="text/javascript" src="../js/bootstrap.min.js"></script>
</html>