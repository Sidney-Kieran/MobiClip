<?php
session_start();
if (!isset($_SESSION['cus_ID'])){
    header("location:../");

}
include "../functions/conn.php";
include "../functions/entities/product.php";
include "../functions/DAO/productDAO.php";
include "../functions/DAO/cartDAO.php";
include "../functions/entities/category.php";
include "../functions/DAO/categoryDAO.php";

$total = 0;
?>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>MOBICLIP | Cart</title>
    <link rel="icon" href="../images/logo_small.png">
    <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Open+Sans" />
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <?php include "../includes/header.php";?>
    <main>
        <div>
            <div class="container">
                <div><h3 class="text-center"><?php echo $_SESSION['cus_name']?>'s CART</h3></div>
                <div class="row">
                    <div class="col-sm-8">
<!--                        <div class="well"></div>-->
                        <?php foreach (allInCart($_SESSION['cus_ID']) as $product):?>
                            <div class="row cartProduct">
                                <div class="col-sm-8 productLeft">
                                    <div class="">
                                        <div class="col-sm-5 removeLeftPadding">
                                            <img src="../admin_area/<?= $product->getFrontPic()?>" class="img-responsive">
                                        </div>
                                        <div class="col-sm-7">
                                            <p><?= $product->getProductName() ?></p>
                                            <h4><?= $product->getPrice() ?>FCFA</h4>
                                            <p><?= $product->getRam() ?>GB</p>
                                            <p><?= $product->getProcessor() ?></p>
                                            <p><?= $product->getProductColor() ?></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="cartBtn">
                                        <div class="col-sm-6">
                                            <a href="../functions/formHandling/cart.php?delete=<?= $product->getProductID()?>"><buttom class="buyBtn">Delete</buttom></a>
                                        </div>
                                        <div class="col-sm-6">
                                            <form action="../checkout/" method="POST">
                                                <input type="hidden" name="productID" value="<?= $product->getProductID()?>">
                                                <input type="hidden" name="productName" value="<?= $product->getProductName()?>">
                                                <input type="hidden" name="price" value="<?= $product->getPrice()?>">
                                                <input type="hidden" name="image" value="<?= $product->getFrontPic()?>">
                                                <input type="hidden" name="maxQuantity" value="<?= $product->getQuantity()?>">
                                                <button class="buyBtn" type="submit">Order</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php $total=$total+$product->getPrice();?>
                        <?php endforeach;?>
                    </div>
                    <div class="col-sm-4">
                        <div class="cartProduct total">
                            <h2 class="bottomLine">TOTAL</h2>
                            <h1>
                                <?php
                                echo $total;
                                ?>
                                FCFA
                            </h1>
                        </div>
                        <a href="../checkoutAll"><button class="buyBtn btn-block">Order All</button></a>
                    </div>
                </div>
            </div>
        </div>
    </main>
</body>
<script type="text/javascript" src="../js/jquery-3.1.0.min.js"></script>
<script type="text/javascript" src="../js/bootstrap.min.js"></script>
</html>