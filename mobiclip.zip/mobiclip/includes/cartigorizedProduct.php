<?php foreach(categorizedList(10,$_GET['view']) as $product) :?>
    <div class="col-sm-4">
        <div class="product">
            <div data-target="#product<?=$product->getProductID()?>" data-toggle="modal"><img src='<?= "admin_area/". $product->getFrontPic();?>' class='img-responsive' alt='<?= $product->getProductName();?>'></div>
            <div>
                <div  class="container-fluid productName">
                    <span><?= $product->getProductName();?></span>
                </div>
                <div  class="container-fluid bottomLine">
                    <h2 class="text-right"><?= $product->getPrice()."FCFA";?></h2>
                </div>
                <div  class="container-fluid bottomLine">
                    <p><strong>RAM: </strong><?= $product->getRam()."GB";?></p>
                </div>
                <div  class="container-fluid bottomLine">
                    <p><strong>Processor: </strong><?= $product->getProcessor();?></p>
                </div>
                <div  class="container-fluid bottomLine">
                    <p><strong>Color: </strong><?= $product->getProductColor();?></p>
                </div>
                <div  class="container-fluid addBtn">
                    <a href="functions/formHandling/cart.php?product=<?= $product->getProductID();?>"><button class="buyBtn btn-block">Add To Cart</button></a>
                </div>
            </div>
        </div>
    </div>
<?php endforeach;?>