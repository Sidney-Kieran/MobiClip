<footer>
    <div>
        <div class="container">
            <div class="row">
                <div class="col-sm-4">
                    <h3 class="bottomLine">Related Sites</h3>
                </div>
                <div class="col-sm-4">
                    <h3 class="bottomLine">Related Sites</h3>
                </div>
                <div class="col-sm-4">
                    <h3 class="bottomLine">Related Sites</h3>
                </div>
            </div>
        </div>
    </div>
    <div class="bottomFooter">

    </div>
</footer>