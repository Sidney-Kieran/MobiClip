<?php
    $page = $_SERVER['PHP_SELF'];


    if (isset($_SESSION['cus_ID'])){
        $cartCount = numberInCart($_SESSION['cus_ID']);
    }else{
        $cartCount = 0;
    }
?>

<header>
    <nav class="navbar navbar-default">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <?php if($page=='/mobiclip/index.php'):?>
                        <li class="navBorder"><a href="">Home</a></li>
                    <?php endif;?>
                    <?php if($page!='/mobiclip/index.php'):?>
                        <li class="navBorder"><a href="../">Home</a></li>
                    <?php endif;?>
                    <li class="dropdown navBorder">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Products<span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <?php if($page=='/mobiclip/index.php'):?>
                                <?php foreach (allCategories() as $category):?>
                                    <li><a href="products?view=<?= $category->getCategoryID()?>"><p><?= $category->getCategoryName();?></p></a></li>
                                <?php endforeach;?>
                            <?php endif;?>
                            <?php if($page!='/mobiclip/index.php'):?>
                                <?php foreach (allCategories() as $category):?>
                                    <li><a href="../products?view=<?= $category->getCategoryID();?>"><p><?= $category->getCategoryName();?></p></a></li>
                                <?php endforeach;?>
                            <?php endif;?>
                        </ul>
                    </li>
                    <li class="navBorder"><a href="#">Help</a></li>
                    <li><a href="#">Contact</a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li class="navBorder">
                        <?php if (isset($_SESSION['cus_ID'])):?>
                            <a><?= $_SESSION['cus_name']?></a>
                        <?php endif;?>
                        <?php if (!isset($_SESSION['cus_ID']) && $page=='/mobiclip/index.php'):?>
                            <a href="register">Register</a>
                        <?php endif;?>
                        <?php if (!isset($_SESSION['cus_ID']) && $page!='/mobiclip/index.php'):?>
                            <a href="../register">Register</a>
                        <?php endif;?>
                    </li>

                    <?php if (isset($_SESSION['cus_ID']) && $page=='/mobiclip/index.php'):?>
                        <li class="navBorder"><a href="functions/logout.php">Logout</a></li>
                    <?php endif;?>
                    <?php if (isset($_SESSION['cus_ID']) && $page!='/mobiclip/index.php'):?>
                        <li class="navBorder"><a href="../functions/logout.php">Logout</a></li>
                    <?php endif;?>
                    <?php if (!isset($_SESSION['cus_ID']) && $page=='/mobiclip/index.php'):?>
                        <li><a href="register">Login</a></li>
                    <?php endif;?>
                    <?php if (!isset($_SESSION['cus_ID']) && $page!='/mobiclip/index.php'):?>
                        <li class="navBorder"><a href="../register">Login</a></li>
                    <?php endif;?>
                    <li>
                        <?php if ($page!='/mobiclip/index.php'){
                            include "../includes/translate.php";
                        }else{
                            include "includes/translate.php";
                        }
                        ?>
                    </li>

                </ul>
            </div>
        </div>
    </nav>
    <div id="topband">
        <div class="container">
            <div class="row">
                <div class="col-sm-3">
                    <div>
                        <a href="">
                            <?php if($page!='/mobiclip/index.php'):?>
                                 <img src="../images/logo_small.png" alt="mobiclip logo" class="img-responsive">
                            <?php endif;?>
                            <?php if($page=='/mobiclip/index.php'):?>
                                <img src="images/logo_small.png" alt="mobiclip logo" class="img-responsive">
                            <?php endif; ?>

                        </a>
                    </div>
                </div>
                <div class="col-sm-6 seach">
                    <div class="row searchContact">
                        <div class="col-xs-6 col-sm-6">
                            <div><span class="glyphicon glyphicon-earphone"> </span>(+237) 654 987 820</div>
                        </div>
                        <div class="col-xs-6 col-sm-6">
                            <div><span class="glyphicon glyphicon-envelope"> </span>info@mobiclip.biz</div>
                        </div>
                    </div>
                    <form action="#" method="get">
                        <div class="form-group">
                            <input type="search" name='query' class="form-control searchField" placeholder="Search">
                        </div>
                    </form>
                </div>
                <div class="col-sm-3">
                    <div class="cart">
                        <?php if($page=='/mobiclip/index.php'):?>
                        <a href="cart">
                        <?php endif; ?>
                            <?php if($page!='/mobiclip/index.php'):?>
                            <a href="../cart">
                            <?php endif; ?>
                            <div class="cartNum"><span class="badge"><?=$cartCount;?></span></div>
                            <div>
                                <?php if($page!='/mobiclip/index.php'):?>
                                    <img src="../images/cart.png" class="img-responsive" alt="moclip shoping cart">
                                <?php endif; ?>
                                <?php if($page=='/mobiclip/index.php'):?>
                                    <img src="images/cart.png" class="img-responsive" alt="moclip shoping cart">
                                <?php endif; ?>

                            </div>

                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>