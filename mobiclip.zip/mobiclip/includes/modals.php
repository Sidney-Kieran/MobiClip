<?php foreach(productList(0) as $product) :?>
<div class="modal fade"  id="product<?= $product->getProductID()?>" role="dialog">
    <div class="modal-dialog modal-lg product_modal">
<!--            <div class="header">-->
<!---->
<!--            </div>-->
            <div class="body">
                <div>
                    <?php if($page=='/mobiclip/index.php'):?>
                        <img src="admin_area/<?= $product->getFrontPic()?>" class="img-responsive" data-dismiss="modal">
                    <?php endif;?>
                    <?php if($page!='/mobiclip/index.php'):?>
                        <img src="../admin_area/<?= $product->getFrontPic()?>" class="img-responsive" data-dismiss="modal">
                    <?php endif;?>
                </div>
            </div>
        <div class="productName text-center"><?= $product->getProductName()?></div>
        </div>
    </div>
</div>
<?php endforeach;?>