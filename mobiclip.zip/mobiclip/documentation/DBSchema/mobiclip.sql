-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 29, 2016 at 09:39 PM
-- Server version: 5.5.24-log
-- PHP Version: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mobiclip`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE IF NOT EXISTS `admins` (
  `adminID` int(225) unsigned NOT NULL AUTO_INCREMENT,
  `adminName` varchar(50) NOT NULL,
  `adminEmail` varchar(50) NOT NULL,
  `adminPassword` varchar(50) NOT NULL,
  `regDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`adminID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE IF NOT EXISTS `brands` (
  `brandID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `brandName` varchar(45) NOT NULL,
  `brandLogo` varchar(100) NOT NULL,
  `regDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admins_adminID` int(10) unsigned NOT NULL,
  PRIMARY KEY (`brandID`,`admins_adminID`),
  UNIQUE KEY `brandID_UNIQUE` (`brandID`),
  UNIQUE KEY `brandName_UNIQUE` (`brandName`),
  UNIQUE KEY `brandLogo_UNIQUE` (`brandLogo`),
  KEY `fk_brands_admins_idx` (`admins_adminID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE IF NOT EXISTS `cart` (
  `cartID` int(11) NOT NULL AUTO_INCREMENT,
  `quatity` int(11) NOT NULL,
  `regDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `customers_customerID` int(10) unsigned NOT NULL,
  `products_productID` int(10) unsigned NOT NULL,
  PRIMARY KEY (`cartID`,`customers_customerID`,`products_productID`),
  UNIQUE KEY `cartID_UNIQUE` (`cartID`),
  KEY `fk_cart_customers1_idx` (`customers_customerID`),
  KEY `fk_cart_products1_idx` (`products_productID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `categoryID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `categoryName` varchar(45) NOT NULL,
  `regDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admins_adminID` int(10) unsigned NOT NULL,
  PRIMARY KEY (`categoryID`,`admins_adminID`),
  UNIQUE KEY `categoryID_UNIQUE` (`categoryID`),
  UNIQUE KEY `categoryName_UNIQUE` (`categoryName`),
  KEY `fk_categories_admins1_idx` (`admins_adminID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE IF NOT EXISTS `customers` (
  `customerID` int(225) unsigned NOT NULL AUTO_INCREMENT,
  `customerName` varchar(50) NOT NULL,
  `customerEmail` varchar(50) NOT NULL,
  `customerPassword` varchar(225) NOT NULL,
  `regDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`customerID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `orderID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `quantity` int(11) NOT NULL,
  `regDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `customers_customerID` int(10) unsigned NOT NULL,
  `products_productID` int(10) unsigned NOT NULL,
  PRIMARY KEY (`orderID`,`customers_customerID`,`products_productID`),
  UNIQUE KEY `orderID_UNIQUE` (`orderID`),
  KEY `fk_orders_customers1_idx` (`customers_customerID`),
  KEY `fk_orders_products1_idx` (`products_productID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE IF NOT EXISTS `payments` (
  `paymentID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `quantity` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `regDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `customers_customerID` int(10) unsigned NOT NULL,
  `products_productID` int(10) unsigned NOT NULL,
  PRIMARY KEY (`paymentID`,`customers_customerID`,`products_productID`),
  UNIQUE KEY `paymentID_UNIQUE` (`paymentID`),
  KEY `fk_payments_customers1_idx` (`customers_customerID`),
  KEY `fk_payments_products1_idx` (`products_productID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `productID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `productName` varchar(45) NOT NULL,
  `productColor` varchar(45) NOT NULL,
  `RAM` varchar(20) NOT NULL,
  `processor` varchar(45) NOT NULL,
  `frontPic` varchar(100) NOT NULL,
  `sidePic` varchar(100) NOT NULL,
  `backPic` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `regDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `categories_categoryID` int(10) unsigned NOT NULL,
  `admins_adminID` int(10) unsigned NOT NULL,
  `brands_brandID` int(10) unsigned NOT NULL,
  PRIMARY KEY (`productID`,`categories_categoryID`,`admins_adminID`,`brands_brandID`),
  UNIQUE KEY `productID_UNIQUE` (`productID`),
  KEY `fk_products_categories1_idx` (`categories_categoryID`),
  KEY `fk_products_admins1_idx` (`admins_adminID`),
  KEY `fk_products_brands1_idx` (`brands_brandID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `brands`
--
ALTER TABLE `brands`
  ADD CONSTRAINT `fk_brands_admins` FOREIGN KEY (`admins_adminID`) REFERENCES `admins` (`adminID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `fk_cart_customers1` FOREIGN KEY (`customers_customerID`) REFERENCES `customers` (`customerID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_cart_products1` FOREIGN KEY (`products_productID`) REFERENCES `products` (`productID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `categories`
--
ALTER TABLE `categories`
  ADD CONSTRAINT `fk_categories_admins1` FOREIGN KEY (`admins_adminID`) REFERENCES `admins` (`adminID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `fk_orders_customers1` FOREIGN KEY (`customers_customerID`) REFERENCES `customers` (`customerID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_orders_products1` FOREIGN KEY (`products_productID`) REFERENCES `products` (`productID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `fk_payments_customers1` FOREIGN KEY (`customers_customerID`) REFERENCES `customers` (`customerID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_payments_products1` FOREIGN KEY (`products_productID`) REFERENCES `products` (`productID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `fk_products_categories1` FOREIGN KEY (`categories_categoryID`) REFERENCES `categories` (`categoryID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_products_admins1` FOREIGN KEY (`admins_adminID`) REFERENCES `admins` (`adminID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_products_brands1` FOREIGN KEY (`brands_brandID`) REFERENCES `brands` (`brandID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
