<?php
/**
 * Created by PhpStorm.
 * User: Sidney
 * Date: 9/1/2016
 * Time: 10:25 AM
 */
session_start();
if (isset($_SESSION['mobiclip_ID']) || isset($_SESSION['cus_ID'])){
    session_unset();
    session_destroy();
    header("location:../");
}