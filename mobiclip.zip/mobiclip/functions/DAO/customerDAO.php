<?php
/**
 * Created by PhpStorm.
 * User: Sidney
 * Date: 8/31/2016
 * Time: 9:44 AM
 */

function newCustomer($customerName,$customerEmail,$customerPassword){
    include '../conn.php';
    $sql = 'INSERT INTO customers(customerName, customerEmail, customerPassword) VALUES(?,?,?)';
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('sss', $customerName, $customerEmail, $customerPassword);
    if ($stmt->execute()){
        return true;
    }else{
        return false;
    }
}

function customerList(){
    global $conn;
    $cusList = array();
    $sql = 'SELECT customerID,customerName,customerEmail,regDate FROM customers';
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $stmt->bind_result($customerID,$customerName, $customerEmail, $regDate);
    while ($stmt->fetch()){
        $cusList[] = new Customer($customerID, $customerName, $customerEmail, $regDate);
    }

    return $cusList;
}

function checkIfExist($customerEmail, $customerPassword){
    global $conn;
    $sql = 'SELECT * FROM customers WHERE customerEmail=? AND customerPassword=?';
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss",$customerEmail, $customerPassword);
    $stmt->execute();
   if ($stmt->fetch()){
        return true;
    }else{
       return false;
   }
}