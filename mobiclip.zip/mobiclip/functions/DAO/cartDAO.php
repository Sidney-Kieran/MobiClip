<?php
/**
 * Created by PhpStorm.
 * User: Sidney
 * Date: 9/1/2016
 * Time: 3:58 PM
 */

function addToCart($productID, $customerID){
    global $conn;
    $sql = "INSERT INTO cart(customers_customerID, products_productID) VALUES(?,?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $customerID, $productID);

    if ($stmt->execute()){
        return true;
    }else{
        return false;
    }
}

function exitsInCart($productID, $customerID){
    global $conn;
    $sql = "SELECT * FROM cart WHERE products_productID=? AND customers_customerID=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $productID, $customerID);
    $stmt->execute();
    if ($stmt->fetch()){
        return true;
    }else{
        return false;
    }
}

function numberInCart($customerID){
    global $conn;
    $sql = "SELECT * FROM cart WHERE customers_customerID=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $customerID);
    $stmt->execute();
    $count = 0;
    while ($stmt->fetch()){
        $count++;
    }

    return $count;
}

function allInCart($customerID){
    global $conn;
    $allProducts = productList();
    $productList = array();
    $sql = "SELECT products_productID FROM cart WHERE customers_customerID=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $customerID);
    $stmt->execute();
    $stmt->bind_result($productID);
    while ($stmt->fetch()){
        foreach ($allProducts as $product){
            if ($product->getProductID() == $productID){
                $productList[] = $product;
            }
        }
    }

    return $productList;
}

function deleteFromCart($productID, $customerID){
    global $conn;
    $sql = "DELETE FROM cart WHERE products_productID = ? AND customers_customerID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $productID, $customerID);
    if ($stmt->execute()){
        return true;
    }else{
        return false;
    }
}