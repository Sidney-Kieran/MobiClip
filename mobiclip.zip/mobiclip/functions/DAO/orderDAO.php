<?php
/**
 * Created by PhpStorm.
 * User: Sidney
 * Date: 8/31/2016
 * Time: 10:21 AM
 */

function newOrder($quantity, $customers_customerID, $products_productID){
    global $conn;
    $sql = "INSERT INTO orders(quantity, customers_customerID, products_productID) VALUES(?,?,?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iii",$quantity, $customers_customerID, $products_productID);
    if ($stmt->execute()){
        return true;
    }else{
        return false;
    }
}

function orderList(){
    include '';
}