<?php
/**
 * Created by PhpStorm.
 * User: Sidney
 * Date: 9/6/2016
 * Time: 12:43 PM
 */


function newPayment($quantity, $amount, $productID, $customerID){
    global $conn;
    $sql = "INSERT INTO payments(quantity, amount, customers_customerID, products_productID) VALUES(?,?,?,?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iiii", $quantity, $amount, $productID, $customerID);

    if ($stmt->execute()){
        return true;
    }else{
        return false;
    }
}