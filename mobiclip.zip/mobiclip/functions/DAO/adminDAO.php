<?php
/**
 * Created by PhpStorm.
 * User: Sidney
 * Date: 8/31/2016
 * Time: 10:10 AM
 */

function newAdmin($adminName,$adminEmail,$adminPassword){
    global $conn;
    $sql = 'INSERT INTO admins(adminName, adminEmail, adminPassword) VALUES(?,?,?)';
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('sss', $adminName, $adminEmail, $adminPassword);
    if ($stmt->execute()){
        return true;
    }else{
        return false;
    }
}

function adminList(){
    global $conn;
    $adminList = array();
    $sql = 'SELECT adminID,adminName,adminEmail,regDate FROM admins';
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $stmt->bind_result($adminID,$adminName, $adminEmail, $regDate);
    while ($stmt->fetch()){
        $adminList[] = new Admin($adminID, $adminName, $adminEmail, $regDate);
    }

    return $adminList;
}

function checkAdmin($email){
    global $conn;
    $sql = 'SELECT adminID FROM admins WHERE adminEmail=?';
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s",$email);
    $stmt->execute();
    if ($stmt->fetch()){
        return true;
    }else{
        return false;
    }

}