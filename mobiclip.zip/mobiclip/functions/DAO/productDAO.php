<?php
/**
 * Created by PhpStorm.
 * User: Sidney
 * Date: 8/31/2016
 * Time: 10:55 AM
 */

function newProduct($productName, $productPic, $ram, $color, $processor, $quantity, $adminID, $categoryID, $brandID, $price){
    global $conn;
    $sql="INSERT INTO products(productName, frontPic, RAM, productColor, processor, quantity, admins_adminID, categories_categoryID, brands_brandID, price) VALUES (?,?,?,?,?,?,?,?,?,?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssiiiis", $productName, $productPic, $ram, $color, $processor, $quantity, $adminID, $categoryID, $brandID, $price);

    if ($stmt->execute()){
        return true;
    }else{
        return false;
    }
}

function productList($number=0){
    global $conn;
    $proList = array();
    $sql = "SELECT * FROM products WHERE quantity!=0 ORDER BY(productID) DESC";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $stmt->bind_result($productID, $productName, $color, $ram, $processor, $productPic, $quantity, $price, $regDate, $categoryID, $adminID,  $brandID);
    $count=0;
    while ($stmt->fetch()){
        if ($number != 0 && $number==$count){
            return $proList;
        }
        $proList[] = new Product($productID,$productName,$color,$ram,$processor,$productPic,$quantity,$price,$categoryID,$adminID,$brandID,$regDate);
        $count++;
    }

    return $proList;
}

function categorizedList($number=0, $catID){
    global $conn;
    $proList = array();
    $sql = "SELECT * FROM products WHERE quantity!=0 AND categories_categoryID = ? ORDER BY(productID) DESC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i",$catID);
    $stmt->execute();
    $stmt->bind_result($productID, $productName, $color, $ram, $processor, $productPic, $quantity, $price, $regDate, $categoryID, $adminID,  $brandID);
    $count=0;
    while ($stmt->fetch()){
        if ($number != 0 && $number==$count){
            return $proList;
        }
        $proList[] = new Product($productID,$productName,$color,$ram,$processor,$productPic,$quantity,$price,$categoryID,$adminID,$brandID,$regDate);
        $count++;
    }

    return $proList;
}

function reduceQty($productID, $qty){
    global $conn;
    $sql = "UPDATE products SET quantity = quantity-? WHERE productID = ?";
    $stmt=$conn->prepare($sql);
    $stmt->bind_param("ii", $qty, $productID);
    if ($stmt->execute()){
        return true;
    }else{
        return false;
    }
}
