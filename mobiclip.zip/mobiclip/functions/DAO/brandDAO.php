<?php
/**
 * Created by PhpStorm.
 * User: Sidney
 * Date: 8/31/2016
 * Time: 9:24 AM
 */

function newBrand($brandName, $brandLogo, $adminID){
    global $conn;
    $sql = "INSERT INTO brands(brandName, brandLogo, admins_adminID) VALUES(?,?,?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $brandName, $brandLogo, $adminID);
    if ($stmt->execute()){
        return true;
    }else{
        return false;
    }
}

function allBrands(){
    global $conn;
    $brandList = array();
    $sql = "SELECT * FROM brands";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $stmt->bind_result($brandID,$brandName,$brandLogo,$regDate,$adminID);
    while($stmt->fetch()){
        $brandList[] = new Brand($brandID,$brandName,$brandLogo,$adminID,$regDate);
    }

    return $brandList;
}