<?php
/**
 * Created by PhpStorm.
 * User: Sidney
 * Date: 8/31/2016
 * Time: 4:33 PM
 */

function newCategory($categoryName, $adminID){
    global $conn;
    $sql = "INSERT INTO categories(categoryName, admins_adminID) VALUES(?,?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $categoryName, $adminID);
    if ($stmt->execute()){
        return true;
    }else{
        return false;
    }
}

function allCategories(){
    global $conn;
    $catList = array();
    $sql = "SELECT * FROM categories";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $stmt->bind_result($catID,$catName,$regDate,$adminID);
    while($stmt->fetch()){
        $catList[] = new Category($catID, $catName, $adminID, $regDate);
    }

    return $catList;
}