<?php
/**
 * Created by PhpStorm.
 * User: Sidney
 * Date: 8/30/2016
 * Time: 9:09 AM
 */

class Brand{
    var $brandID;
    var $brandName;
    var $brandLogo;
    var $adminID;
    var $regDate;

    /**
     * Brand constructor.
     * @param $brandID
     * @param $brandName
     * @param $brandLogo
     * @param $adminID
     * @param $regDate
     */
    public function __construct($brandID, $brandName, $brandLogo, $adminID, $regDate)
    {
        $this->brandID = $brandID;
        $this->brandName = $brandName;
        $this->brandLogo = $brandLogo;
        $this->adminID = $adminID;
        $this->regDate = $regDate;
    }

    /**
     * @return mixed
     */
    public function getBrandID()
    {
        return $this->brandID;
    }

    /**
     * @return mixed
     */
    public function getBrandName()
    {
        return $this->brandName;
    }

    /**
     * @return mixed
     */
    public function getBrandLogo()
    {
        return $this->brandLogo;
    }

    /**
     * @return mixed
     */
    public function getAdminID()
    {
        return $this->adminID;
    }

    /**
     * @return mixed
     */
    public function getRegDate()
    {
        return $this->regDate;
    }


}

