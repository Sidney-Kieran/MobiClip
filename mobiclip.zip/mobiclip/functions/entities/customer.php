<?php
/**
 * Created by PhpStorm.
 * User: Sidney
 * Date: 8/30/2016
 * Time: 8:56 AM
 */

class Customer{
    var $customerID;
    var $customerName;
    var $customerEmail;
    var $regDate;

    public function __construct($customerID, $customerName, $customerEmail, $regDate)
    {
        $this->customerID = $customerID;
        $this->customerName = $customerName;
        $this->customerEmail = $customerEmail;
        $this->regDate = $regDate;
    }

    /**
     * @return mixed
     */
    public function getCustomerID()
    {
        return $this->customerID;
    }


    /**
     * @return mixed
     */
    public function getCustomerName()
    {
        return $this->customerName;
    }


    /**
     * @return mixed
     */
    public function getCustomerEmail()
    {
        return $this->customerEmail;
    }


    /**
     * @return mixed
     */
    public function getRegDate()
    {
        return $this->regDate;
    }



}