<?php

/**
 * Created by PhpStorm.
 * User: Sidney
 * Date: 8/30/2016
 * Time: 9:23 AM
 */
class Product
{
    var $productID;
    var $productName;
    var $productColor;
    var $ram;
    var $processor;
    var $frontPic;
    var $quantity;
    var $price;
    var $categoryID;
    var $adminID;
    var $brandID;
    var $regDate;
    var $orderQty;

    /**
     * @return mixed
     */
    public function getOrderQty()
    {
        return $this->orderQty;
    }

    /**
     * @param mixed $orderQty
     */
    public function setOrderQty($orderQty)
    {
        $this->orderQty = $orderQty;
    }

    /**
     * Product constructor.
     * @param $productID
     * @param $productName
     * @param $productColor
     * @param $ram
     * @param $processor
     * @param $frontPic
     * @param $backPic
     * @param $sidePic
     * @param $quantity
     * @param $price
     * @param $categoryID
     * @param $adminID
     * @param $bandID
     * @param $regDate
     */
    public function __construct($productID, $productName, $productColor, $ram, $processor, $frontPic, $quantity, $price, $categoryID, $adminID, $brandID, $regDate)
    {
        $this->productID = $productID;
        $this->productName = $productName;
        $this->productColor = $productColor;
        $this->ram = $ram;
        $this->processor = $processor;
        $this->frontPic = $frontPic;
        $this->quantity = $quantity;
        $this->price = $price;
        $this->categoryID = $categoryID;
        $this->adminID = $adminID;
        $this->brandID = $brandID;
        $this->regDate = $regDate;
    }

    /**
     * @return mixed
     */
    public function getProductID()
    {
        return $this->productID;
    }

    /**
     * @return mixed
     */
    public function getProductName()
    {
        return $this->productName;
    }

    /**
     * @return mixed
     */
    public function getProductColor()
    {
        return $this->productColor;
    }

    /**
     * @return mixed
     */
    public function getRam()
    {
        return $this->ram;
    }

    /**
     * @return mixed
     */
    public function getProcessor()
    {
        return $this->processor;
    }

    /**
     * @return mixed
     */
    public function getFrontPic()
    {
        return $this->frontPic;
    }

    /**
     * @return mixed
     */
    public function getQuantity()
    {
        return $this->quantity;
    }

    /**
     * @return mixed
     */
    public function getPrice()
    {
        return $this->price;
    }

    /**
     * @return mixed
     */
    public function getCategoryID()
    {
        return $this->categoryID;
    }

    /**
     * @return mixed
     */
    public function getAdminID()
    {
        return $this->adminID;
    }

    /**
     * @return mixed
     */
    public function getBrandID()
    {
        return $this->brandID;
    }

    /**
     * @return mixed
     */
    public function getRegDate()
    {
        return $this->regDate;
    }


}