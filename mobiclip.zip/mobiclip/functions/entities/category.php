<?php

/**
 * Created by PhpStorm.
 * User: Sidney
 * Date: 8/30/2016
 * Time: 9:15 AM
 */
class Category
{
    var $categoryID;
    var $categoryName;
    var $adminID;
    var $regDate;

    /**
     * Category constructor.
     * @param $categoryID
     * @param $categoryName
     * @param $adminID
     * @param $regDate
     */
    public function __construct($categoryID, $categoryName, $adminID, $regDate)
    {
        $this->categoryID = $categoryID;
        $this->categoryName = $categoryName;
        $this->adminID = $adminID;
        $this->regDate = $regDate;
    }

    /**
     * @return mixed
     */
    public function getCategoryID()
    {
        return $this->categoryID;
    }

    /**
     * @return mixed
     */
    public function getCategoryName()
    {
        return $this->categoryName;
    }

    /**
     * @return mixed
     */
    public function getAdminID()
    {
        return $this->adminID;
    }

    /**
     * @return mixed
     */
    public function getRegDate()
    {
        return $this->regDate;
    }


}