<?php

/**
 * Created by PhpStorm.
 * User: Sidney
 * Date: 8/30/2016
 * Time: 10:26 AM
 */
class Payment
{
    var $paymentID;
    var $quantity;
    var $amount;
    var $customerID;
    var $productID;
    var $regDate;

    /**
     * Payment constructor.
     * @param $paymentID
     * @param $quantity
     * @param $amount
     * @param $customerID
     * @param $productID
     * @param $regDate
     */
    public function __construct($paymentID, $quantity, $amount, $customerID, $productID, $regDate)
    {
        $this->paymentID = $paymentID;
        $this->quantity = $quantity;
        $this->amount = $amount;
        $this->customerID = $customerID;
        $this->productID = $productID;
        $this->regDate = $regDate;
    }

    /**
     * @return mixed
     */
    public function getPaymentID()
    {
        return $this->paymentID;
    }

    /**
     * @return mixed
     */
    public function getQuantity()
    {
        return $this->quantity;
    }

    /**
     * @return mixed
     */
    public function getAmount()
    {
        return $this->amount;
    }

    /**
     * @return mixed
     */
    public function getCustomerID()
    {
        return $this->customerID;
    }

    /**
     * @return mixed
     */
    public function getProductID()
    {
        return $this->productID;
    }

    /**
     * @return mixed
     */
    public function getRegDate()
    {
        return $this->regDate;
    }



}