<?php

/**
 * Created by PhpStorm.
 * User: Sidney
 * Date: 8/30/2016
 * Time: 10:49 AM
 */
class Admin
{
    var $adminID;
    var $adminName;
    var $adminEmail;
    var $regDate;

    /**
     * Admin constructor.
     * @param $adminID
     * @param $adminName
     * @param $adminEmail
     * @param $regDate
     */
    public function __construct($adminID, $adminName, $adminEmail, $regDate)
    {
        $this->adminID = $adminID;
        $this->adminName = $adminName;
        $this->adminEmail = $adminEmail;
        $this->regDate = $regDate;
    }

    /**
     * @return mixed
     */
    public function getAdminID()
    {
        return $this->adminID;
    }

    /**
     * @return mixed
     */
    public function getAdminName()
    {
        return $this->adminName;
    }

    /**
     * @return mixed
     */
    public function getAdminEmail()
    {
        return $this->adminEmail;
    }

    /**
     * @return mixed
     */
    public function getRegDate()
    {
        return $this->regDate;
    }


}