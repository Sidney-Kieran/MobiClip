<?php

/**
 * Created by PhpStorm.
 * User: Sidney
 * Date: 8/30/2016
 * Time: 9:38 AM
 */
class Cart
{
    var $cartID;
    var $quantity;
    var $customerID;
    var $productID;
    var $regDate;

    /**
     * Cart constructor.
     * @param $cartID
     * @param $quantity
     * @param $customerID
     * @param $productID
     * @param $regDate
     */
    public function __construct($cartID, $quantity, $customerID, $productID, $regDate)
    {
        $this->cartID = $cartID;
        $this->quantity = $quantity;
        $this->customerID = $customerID;
        $this->productID = $productID;
        $this->regDate = $regDate;
    }

    /**
     * @return mixed
     */
    public function getCartID()
    {
        return $this->cartID;
    }

    /**
     * @return mixed
     */
    public function getQuantity()
    {
        return $this->quantity;
    }

    /**
     * @return mixed
     */
    public function getCustomerID()
    {
        return $this->customerID;
    }

    /**
     * @return mixed
     */
    public function getProductID()
    {
        return $this->productID;
    }

    /**
     * @return mixed
     */
    public function getRegDate()
    {
        return $this->regDate;
    }


}