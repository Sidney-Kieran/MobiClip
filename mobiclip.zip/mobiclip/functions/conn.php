<?php
/**
 * Created by PhpStorm.
 * User: Sidney
 * Date: 8/30/2016
 * Time: 11:59 PM
 */

$server = 'localhost';
$username = 'sidney';
$pw = 'eXD+]hH09zwI';
$db_name = 'sidney_mobiclip';

$conn = new mysqli($server,$username,$pw,$db_name);

if ($conn->error === TRUE){
    echo "failure";
}else{
//    echo "connected";
}