<?php
/**
 * Created by PhpStorm.
 * User: Sidney
 * Date: 8/31/2016
 * Time: 4:30 PM
 */
include '../DAO/categoryDAO.php';
session_start();
$adminID = $_SESSION['mobiclip_ID'];
if (empty($_POST['name'])){
    header("location:../../admin_area/home?action=newCategory&error=Please enter name of category");
}else{
    if (newCategory($_POST['name'], $adminID)){
        header("location:../../admin_area/home?action=newCategory");
    }else{
        echo "not added";
    }
}
