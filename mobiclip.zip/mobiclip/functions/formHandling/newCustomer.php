<?php
/**
 * Created by PhpStorm.
 * User: Sidney
 * Date: 9/1/2016
 * Time: 9:09 PM
 */
include "../conn.php";
include "../DAO/customerDAO.php";
include "validationMethods.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST'){
    $nameErr = $name = $emailErr = $email = $passwordErr = $password = $rePasswordErr = "";

    if (empty($_POST['name'])){
        $nameErr = "Please Enter your name";
    }elseif (!checkName($_POST['name'])){
        $nameErr = "Please name should contain only letters";
    }else{
        $name = sanitizeData($_POST['name']);
    }

    if (empty($_POST['email'])){
        $emailErr = "Please Enter your email";
    }elseif (!checkEmail($_POST['email'])){
        $emailErr = "Please Enter a valid email";
    }else{
        $email = sanitizeData($_POST['email']);
    }

    if (empty($_POST['password'])){
        $passwordErr = "Please Enter password";
    }elseif (strlen($_POST['password'])<6){
        $passwordErr = "Password should be at least 6 characters long";
    }else{
        $password = md5(sanitizeData($_POST['password']));
    }

    if (empty($_POST['repassword'])){
        $rePasswordErr = "Please Retype Password";
    }elseif ($_POST['password']!=$_POST['repassword']){
        $rePasswordErr = "Retyped Password is not same as password";
    }

    if (!empty($nameErr) || !empty($emailErr) || !empty($passwordErr) || !empty($rePasswordErr)){
        header("location:../../register?nameErr=".$nameErr."&emailErr=".$emailErr."&passwordErr=".$passwordErr."&rePasswordErr=".$rePasswordErr);
    }elseif(!checkIfExist($email,$password)){
        if (newCustomer($name,$email,$password)){
            header("location:../../");
        }else{
//            header("location:../../register);
        }
    }else{
        header("location:../../register?signUpErr=User Already exist with thesame username and password combination");
    }

}