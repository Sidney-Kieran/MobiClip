<?php
/**
 * Created by PhpStorm.
 * User: Sidney
 * Date: 9/1/2016
 * Time: 3:36 PM
 */
include "../conn.php";
include "../DAO/cartDAO.php";
session_start();
if (!isset($_SESSION['cus_ID'])){
    header("location:../../register");
}
if(isset($_GET['product'])){
    if (!exitsInCart($_GET['product'], $_SESSION['cus_ID'])){
        $add = addToCart($_GET['product'], $_SESSION['cus_ID']);
        if ($add){
            header("location:../../");
        }else{
            echo "no";
        }
    }else{
        if (isset($_GET['source'])){
            header("location:../../products?view=".$_GET['source']."&cartErr=Item already exist in cart");
        }else{
            header("location:../../?cartErr=Item already exist in cart");
        }

    }

}

if (isset($_GET['delete'])){
    if (deleteFromCart($_GET['delete'], $_SESSION['cus_ID'])){
        header("location:../../cart/");
    }else{
        echo "not deleted";
    }
}