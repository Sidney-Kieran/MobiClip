<?php
/**
 * Created by PhpStorm.
 * User: Sidney
 * Date: 8/31/2016
 * Time: 5:37 PM
 */
include 'validationMethods.php';
include 'imageUpload.php';
include '../DAO/brandDAO.php';
session_start();
$adminID = $_SESSION['mobiclip_ID'];
//echo $_POST['name'];
if ($_SERVER['REQUEST_METHOD']=='POST'){
//    echo $_POST['name'];
    $name = $nameErr = $logoErr= "";
   if (empty($_POST['name'])){
        $nameErr = 'Enter Name of Brand';
   }else{
        $name=sanitizeData($_POST['name']);
   }

   if (empty($_FILES['logo']['name'])){
       $logoErr = 'Choose a logo for the brand';
   }else{
       $logo = $_FILES['logo'];
   }

   if (empty($nameErr) && empty($logoErr)){
//       echo $name."<br>";
//       echo $logo['name'];
       $upload = uploadImg("../../images/brands/", $logo);
       $theLogo = "images/brands/".$logo['name'];
       if ($upload==1){
           if (newBrand($name,$theLogo,$adminID)){
              header("location:../../admin_area/home?action=newBrand");
           }else{
               echo "no";
           }
       }else{
           if (isset($upload['typeErr'])){
               $logoErr = $upload['typeErr'];
           }else{
               $logoErr = $upload['general'];
           }
           echo $upload['typeErr'];
       }
   }else{
       header("location:../../admin_area/home?action=newBrand&nameErr=".$nameErr."&uploadErr=".$logoErr);
   }
}