<?php
/**
 * Created by PhpStorm.
 * User: Sidney
 * Date: 8/31/2016
 * Time: 9:14 PM
 */
include 'validationMethods.php';
include 'imageUpload.php';
include '../DAO/productDAO.php';
include '../conn.php';
session_start();
$adminID = $_SESSION['mobiclip_ID'];
if ($_SERVER['REQUEST_METHOD']=='POST'){
    $name = $color = $ram = $processor = $price = $quantity = $category = $brand = $picture = "";
    $nameErr = $colorErr = $ramErr = $processorErr = $priceErr = $quantityErr = $pictureErr = "";


    if (empty($_POST['name'])){
        $nameErr = 'Please Enter name of Product';
    }else{
        $name = sanitizeData($_POST['name']);
    }

    if (empty($_POST['color'])){
        $colorErr = 'Please Enter color of Product';
    }else{
        $color = sanitizeData($_POST['color']);
    }

    if (empty($_POST['ram'])){
        $ramErr = 'Please Enter RAM capacity of Product';
    }elseif (!checkNumber($_POST['ram'])){
        $ramErr = 'RAM capacity should be in figures only';
    }else{
        $ram = sanitizeData($_POST['ram']);
    }

    if (empty($_POST['processor'])){
        $processorErr = 'Please Enter Processor Specification of Product';
    }else{
        $processor = sanitizeData($_POST['processor']);
    }

    if (empty($_POST['price'])){
        $priceErr = 'Please Enter Unit Price of Product';
    }elseif (!checkNumber($_POST['price'])){
        $priceErr = 'Price Must be in Figures';
    }else{
        $price = sanitizeData($_POST['price']);
    }

    if (empty($_POST['quantity'])){
        $quantityErr = 'Please Enter Quantity of Product in Stock';
    }elseif (!checkNumber($_POST['quantity'])){
        $quantityErr = 'Quantity Must be in Figures';
    }else{
        $quantity = sanitizeData($_POST['quantity']);
    }

    if (empty($_FILES['picture']['name'])){
        $pictureErr = 'Upload a picture of the product';
    }else{
        $picture = $_FILES['picture'];
    }

    $category=$_POST['category'];
    $brand=$_POST['brand'];

    if (empty($nameErr) && empty($colorErr) && empty($ramErr) && empty($processorErr) && empty($priceErr) && empty($quantityErr) && empty($pictureErr)){
        $upload = uploadImg("../../admin_area/products/", $picture);
        $picture = "products/".$picture['name'];

        if ($upload==1){
            if (newProduct($name, $picture, $ram, $color, $processor, $quantity, $adminID, $category, $brand, $price)){
                header("location:../../admin_area/home?action=newProduct");
            }else{
              
            }
        }else{
            if (isset($upload['typeErr'])){
                $pictureErr = $upload['typeErr'];
            }else{
                $pictureErr = $upload['general'];
            }
           
        }

       
    }else{
        header("location:../../admin_area/home?action=newProduct&nameErr=".$nameErr."&colorErr=".$colorErr."&ramErr".$ramErr."&processorErr=".$processorErr."&priceErr=".$priceErr."&quantityErr=".$quantityErr."&pictureErr=".$pictureErr);
        
    }

}