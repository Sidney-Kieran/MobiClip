<?php
/**
 * Created by PhpStorm.
 * User: Sidney
 * Date: 9/3/2016
 * Time: 8:27 AM
 */
include '../conn.php';
include '../DAO/adminDAO.php';
include 'validationMethods.php';
if ($_SERVER['REQUEST_METHOD']=='POST'){
    if (empty($_POST['name']) || empty($_POST['email'])){
        header("location:../../admin_area/home?action=newAdmin&error=All Fields are required");
    }elseif(checkAdmin($_POST['email'])){
        header("location:../../admin_area/home?action=newAdmin&error=Admin Already exits with this email");
    }else{
        if(newAdmin(sanitizeData($_POST['name']), sanitizeData($_POST['email']), md5('admin'))){
            header("location:../../admin_area/home?action=newAdmin");
        }
    }
}