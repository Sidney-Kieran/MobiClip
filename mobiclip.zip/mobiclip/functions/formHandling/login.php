<?php
/**
 * Created by PhpStorm.
 * User: Sidney
 * Date: 8/30/2016
 * Time: 11:58 PM
 */



if (isset($_GET['source'])){
    if ($_GET['source']=='admin'){
//        echo $_POST['email'];
//        echo $_POST['password'];

        if(login('admins', $_POST['email'], md5($_POST['password']))){
            header("location:../../admin_area/home");
        }else{
            header("location:../../admin_area?error=You are not recognized");
        }
    }elseif ($_GET['source']=='customer'){
        if(login('customers', $_POST['email'], md5($_POST['password']))){
            header("location:../../");
        }else{
            header("location:../../register?error=You are not recognized");
        }
    }
}else{
    header("location:../../");
}

function login($table, $email, $password){
    include "../conn.php";
    if ($table=='admins'){
        $sql = "SELECT * FROM admins WHERE adminEmail=? AND adminPassword=?";
    }else{
        $sql = "SELECT * FROM customers WHERE customerEmail=? AND customerPassword=?";
    }

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $email, $password);
    $stmt->execute();
    $stmt->bind_result($ID, $name, $theEmail , $thePassword, $regDate);


if ($stmt->fetch()){
session_start();
            if ($table =='admins'){
                $_SESSION['mobiclip_ID'] = $ID;
                $_SESSION['mobiclip_name'] = $name;
                $_SESSION['mobiclip_email'] = $theEmail;
                $_SESSION['mobiclip_regDate'] = $regDate;
            }else{
                $_SESSION['cus_ID'] = $ID;
                $_SESSION['cus_name'] = $name;
                $_SESSION['cus_email'] = $theEmail;
                $_SESSION['cus_regDate'] = $regDate;
            }

        return true;
    }else{
        return false;
    }
}