<?php
/**
 * Created by PhpStorm.
 * User: Sidney
 * Date: 8/31/2016
 * Time: 8:45 AM
 */

function sanitizeData($data){
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);

    return $data;
}

function checkEmail($data){
    if (filter_var($data, FILTER_VALIDATE_EMAIL)){
        return true;
    }else{
        return false;
    }
}

function checkName($data){
    if (preg_match('/^[a-zA-Z ]*$/',$data)){
        return true;
    }else{
        return false;
    }
}

function checkNumber($data){
    if (preg_match('/^[0-9]*$/',$data)){
        return true;
    }else{
        return false;
    }
}