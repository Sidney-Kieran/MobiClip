<?php
/**
 * Created by PhpStorm.
 * User: Sidney
 * Date: 9/6/2016
 * Time: 10:06 AM
 */


session_start();
include "conn.php";
include "DAO/orderDAO.php";
include "DAO/paymentDAO.php";
include "DAO/cartDAO.php";
include "DAO/productDAO.php";


if (isset($_GET['qty']) && isset($_GET['total']) && isset($_GET['product'])){
    if (newOrder($_GET['qty'], $_SESSION['cus_ID'], $_GET['product'])){
        if (newPayment($_GET['qty'], $_GET['total'], $_GET['product'], $_SESSION['cus_ID'])){
            if (deleteFromCart($_GET['product'], $_SESSION['cus_ID'])){
                if (reduceQty($_GET['productID'], $_GET['qty'])){
                    header("location:../success");
                }
            }
        }
    }
}

//if (isset($_GET['action'])){
//    foreach ($_GET as $productID=>$qty){
//        foreach (productList() )
//    }
//}