<?php session_start(); ?>
<?php
include "../functions/conn.php";
include "../functions/entities/product.php";
include "../functions/DAO/productDAO.php";
include "../functions/DAO/cartDAO.php";
include "../functions/entities/category.php";
include "../functions/DAO/categoryDAO.php";

if (!isset($_SESSION['cus_ID'])){
    header("location:../");
}
$total=0;
?>
<html xmlns="http://www.w3.org/1999/html">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>MOBICLIP | Checkout</title>
    <link rel="icon" href="../images/logo_small.png">
    <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Open+Sans" />
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php
include "../includes/header.php";
$productArray = array();
?>
<main>
    <div class="container">
        <div><h3 class="text-center">SECURE!!! CHECKOUT WITH PAYPAL</h3></div>
        <div class="row">
            <div class="col-sm-8">
            <?php foreach (allInCart($_SESSION['cus_ID']) as $product):?>
                <?php
                    if (isset($_POST['qty'.$product->getProductID()])){
                        $product->setOrderQty($_POST['qty'.$product->getProductID()]);
                    }elseif (isset($_POST['qt'.$product->getProductID()])){
                        $product->setOrderQty($_POST['qt'.$product->getProductID()]);
                    }else{
                        $product->setOrderQty(1);
                    }
                    $total=$total+($product->getOrderQty()*$product->getPrice());
                    $productArray[$product->getProductID()] = $product->getOrderQty();
                ?>
                <div class="cartProduct row">
                    <div class="col-sm-4 removeLeftPadding checkoutImg">
                        <img src="../admin_area/<?= $product->getFrontPic()?>" class="img-responsive">
                    </div>
                    <div class="col-sm-7">
                        <h2><?= $product->getProductName()?></h2>
                        <!--                        <h4>--><?//= $_REQUEST['price'] ?><!--FCFA</h4>-->
                        <form action="../checkoutAll/" method="POST">
                            <div class="form-group">
                                <label>Quatity</label>
                                <input type="number" name="qty<?= $product->getProductID()?>" class="form-control" min="1" value="<?=$product->getOrderQty()?>" max="<?= $product->getQuantity()?>">
                                <input type="hidden" name="productID" value="<?= $product->getProductID()?>">
                            </div>
                            <?php foreach (allInCart($_SESSION['cus_ID']) as $product):?>
                                <?php
                                if (isset($_POST['qty'.$product->getProductID()])){
                                    $product->setOrderQty($_POST['qty'.$product->getProductID()]);
                                }elseif (isset($_POST['qt'.$product->getProductID()])){
                                    $product->setOrderQty($_POST['qt'.$product->getProductID()]);
                                }else{
                                    $product->setOrderQty(1);
                                }
                                ?>
                                <input type="hidden" name="qt<?= $product->getProductID()?>" class="form-control" value="<?= $product->getOrderQty()?>">
                            <?php endforeach;?>
                            <div class="form-group">
                                <button class="buyBtn" type="submit">Add</button>
                            </div>
                        </form>
                    </div>
                </div>
            <?php endforeach;?>
            </div>
            <div class="col-sm-4">
                <div class="cartTotal total">
                    <h2 class="bottomLine">TOTAL</h2>
                    <h2><?= $total?> FCFA</h2>
                    <!--                paypal integration code-->
                    <form action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="post">

                        <!-- Identify your business so that you can collect the payments. -->
                        <input type="hidden" name="business" value="admin@mobiclip.biz">

                        <!-- Specify a Buy Now button. -->
                        <input type="hidden" name="cmd" value="_xclick">

                        <!-- Specify details about the item that buyers will purchase. -->
                        <input type="hidden" name="item_name" value="All of your cart on mobiclip.biz">
                        <input type="hidden" name="amount" value="<?= $total?>">
                        <input type="hidden" name="currency_code" value="USD">

                        <!-- specify where paypal should redirect after transaction is completed or cancelled-->
                        <input type="hidden" name="return" value="http://www.sidney.kilimanjarosystems.com/mobiclip/functions/order.php?action=all
                            <?php
                        foreach ($productArray as $key=>$value){
                            echo "&product".$key."=".$value;
                        }
                        ?>
                        ">
                        <input type="hidden" name="return_cancel" value="http://www.sidney.kilimanjarosystems.com/mobiclip/cancel">

                        <!-- Display the payment button. -->
                        <input type="image" name="submit" border="0"
                               src="https://www.paypalobjects.com/en_US/i/btn/btn_buynow_LG.gif"
                               alt="PayPal - The safer, easier way to pay online">
                        <img alt="" border="0" width="1" height="1"
                             src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" >

                    </form>
                </div>
                <div>
                    <a href="../"><button class="btn-block buyBtn">Back To Shop</button></a>
                </div>
            </div>
        </div>
    </div>
</main>
<?php include "../includes/footer.php";?>
</body>
<script type="text/javascript" src="../js/jquery-3.1.0.min.js"></script>
<script type="text/javascript" src="../js/bootstrap.min.js"></script>
</html>
<?php
    foreach ($productArray as $key=>$value){
        echo $key."-".$value."<br>";
    }
?>