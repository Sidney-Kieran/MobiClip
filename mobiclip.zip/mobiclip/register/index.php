<?php
session_start();
    if (isset($_SESSION['cus_ID'])){
        header("location:../");

    }
include "../functions/conn.php";
include "../functions/DAO/cartDAO.php";
include "../functions/entities/category.php";
include "../functions/DAO/categoryDAO.php";
include "../functions/entities/product.php";
include "../functions/DAO/productDAO.php";
?>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>MOBICLIP | Register</title>
    <link rel="icon" href="../images/logo_small.png">
    <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Open+Sans" />
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
<main id="log">
    <div class="container">
        <div class="row">
            <div class="col-sm-8">
                <div>
                    <h3 class="lineHeading">Register</h3>
                    <div>
                        <div class="col-sm-6 removeLeftPadding">
                            <form action="../functions/formHandling/newCustomer.php" method="POST">
                                <div class="form-group">
                                    <?php if (isset($_GET['nameErr'])):?>
                                        <div class="text-danger"><?= $_GET['nameErr']?></div>
                                    <?php endif;?>
                                    <label>Full Name</label>
                                    <input type="name" name="name" class="form-control" placeholder="Enter Full Name">
                                </div>
                                <div class="form-group">
                                    <?php if (isset($_GET['emailErr'])):?>
                                        <div class="text-danger"><?= $_GET['emailErr']?></div>
                                    <?php endif;?>
                                    <label>E-mail</label>
                                    <input type="email" name="email" class="form-control" placeholder="Enter Email">
                                </div>
                                <div class="form-group">
                                    <?php if (isset($_GET['passwordErr'])):?>
                                        <div class="text-danger"><?= $_GET['passwordErr']?></div>
                                    <?php endif;?>
                                    <label>Password</label>
                                    <input type="password" name="password" class="form-control" placeholder="Enter new password">
                                </div>
                                <div class="form-group">
                                    <?php if (isset($_GET['rePasswordErr'])):?>
                                        <div class="text-danger"><?= $_GET['rePasswordErr']?></div>
                                    <?php endif;?>
                                    <label>Retype-Password</label>
                                    <input type="password" name="repassword" class="form-control" placeholder="Retype password">
                                </div>
                                <div class="form-group">
                                    <button class="buyBtn btn-block" type="submit">Register</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="">
                    <h3 class="lineHeading">Login</h3>
                    <div>
                        <form action="../functions/formHandling/login.php?source=customer" method="POST">
                            <div class="form-group">
                                <label>E-mail</label>
                                <input type="email" name="email" class="form-control" placeholder="Enter Email">
                            </div>
                            <div class="form-group">
                                <label>Password</label>
                                <input type="password" name="password" class="form-control" placeholder="Enter password">
                            </div>
                            <div class="form-group">
                                <button class="buyBtn btn-block" type="submit">Login</button>
                            </div>
                            <div>
                                <input type="checkbox" value="remember" checked name="remember"> remember me
                            </div>
                        </form>
                        <?php if(isset($_GET['error'])):?>
                            <div class="text-center text-danger"><?= $_GET['error']?></div>
                        <?php endif;?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
    <?php include "../includes/footer.php";?>
</body>
<script type="text/javascript" src="../js/jquery-3.1.0.min.js"></script>
<script type="text/javascript" src="../js/bootstrap.min.js"></script>
</html>