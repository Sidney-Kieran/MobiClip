<?php
session_start();
include "functions/conn.php";
include "functions/entities/product.php";
include "functions/DAO/productDAO.php";
include "functions/DAO/cartDAO.php";
include "functions/entities/category.php";
include "functions/DAO/categoryDAO.php";
$carouselCount=0;
?>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>MOBICLIP | Find the Perfect Phone</title>
    <link rel="icon" href="images/logo_small.png">
    <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Open+Sans" />
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <?php
    $page = $_SERVER['PHP_SELF'];
    include 'includes/modals.php';
    include 'includes/header.php';
    ?>
    <main>
        <?php if (isset($_GET['cartErr'])):?>
            <div class="text-danger text-center"><?= $_GET['cartErr']?></div>
        <?php endif; ?>
        <div id="topMain">
            <div class="container">
                <div class="row">
                    <div class="col-sm-4">
                        <div class="categories">
                            <div class="catHeading"><h4>Categories</h4></div>
                            <div class="cat">
                                <?php foreach (allCategories() as $category):?>
                                <a href="?view=<?= $category->getCategoryID();?>"><p><?= $category->getCategoryName();?></p></a>
                                <?php endforeach;?>
                                <a href=""><p>Latest</p></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8">
                        <div class="">
                            <div id="productCarousel" class="carousel slide" data-ride="carousel">
                                <!-- Wrapper for slides -->
                                <div class="carousel-inner" role="listbox">
                                    <?php foreach(productList(5) as $product) :?>
                                        <?php if ($carouselCount==0):?>
                                            <div class="item active">
                                            <?php endif;?>
                                                <?php if ($carouselCount!=0):?>
                                                <div class="item">
                                                    <?php endif;?>
                                            <div class="row">
                                                <div class="col-xs-6 col-sm-5">
                                                    <h2><?= $product->getProductName()?> SmartPhone</h2>
                                                    <div>
                                                        <span>At Only </span><span class="carouselPrice"><?= $product->getPrice()?>FCFA</span>
                                                    </div>
                                                    <div class="buyBtnContainer">
                                                        <a href="functions/formHandling/cart.php?product=<?= $product->getProductID();?>"><button class="btn-block buyBtn">Buy Me!!</button></a>
                                                    </div>
                                                </div>
                                                <div class="col-xs-6 col-sm-7">
                                                    <img src="<?= "admin_area/". $product->getFrontPic();?>" alt="<?= "admin_area/". $product->getFrontPic();?>" class="img-responsive">
                                                </div>
                                            </div>
                                        </div>
                                                <?php $carouselCount++;?>
                                    <?php endforeach;?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="brands">
            <div class="container">
                <div id="brandCarousel" class="carousel slide" data-ride="carousel">
                    <!-- Wrapper for slides -->
                    <div class="carousel-inner" role="listbox">
                        <div class="item active">
                           <div class="row">
                               <div class="col-xs-4 col-sm-4"><img src="images/brands/apple.png" alt="apple logo on mobiclip" class="img-responsive"></div>
                               <div class="col-xs-4 col-sm-4"><img src="images/brands/Motorola.gif" alt="motorola logo on mobiclip" class="img-responsive"></div>
                               <div class="col-xs-4 col-sm-4"><img src="images/brands/LG.png" alt="LG logo on mobiclip" class="img-responsive"></div>
                           </div>
                        </div>

                        <div class="item">
                            <div class="row">
                                <div class="col-xs-4 col-sm-4"><img src="images/brands/HTC.png" alt="htc logo on mobiclip" class="img-responsive"></div>
                                <div class="col-xs-4 col-sm-4"><img src="images/brands/NOKIA.png" alt="Nokia logo on mobiclip" class="img-responsive"></div>
                                <div class="col-xs-4 col-sm-4"><img src="images/brands/Samsung.png" alt="Samsung logo on mobiclip" class="img-responsive"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="productList container">
            <div class="row">
                <?php
                    if (isset($_GET['view'])){
                        include 'includes/cartigorizedProduct.php';
                    }else{
                        include 'includes/uncategorizedProduct.php';
                    }
                ?>
            </div>
        </div>
    </main>
<?php include "includes/footer.php";?>
</body>
<script type="text/javascript" src="js/jquery-3.1.0.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
</html>