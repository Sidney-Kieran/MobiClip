<?php
session_start();
include "../functions/conn.php";
include "../functions/entities/product.php";
include "../functions/DAO/productDAO.php";
include "../functions/DAO/cartDAO.php";
?>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>MOBICLIP | Success</title>
    <link rel="icon" href="../images/logo_small.png">
    <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Open+Sans" />
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include "../includes/header.php"; ?>
<main>
    <div class="container">
        <div class="text-center">
            <h1>Purchase was completed successfully</h1>
            <h2>Thanks for shopping with us</h2>
            <a href='../'><button class='buyBtn'>< Back to shop</button></a>
        </div>
    </div>
</main>
</body>
<script type="text/javascript" src="../js/jquery-3.1.0.min.js"></script>
<script type="text/javascript" src="../js/bootstrap.min.js"></script>
</html>