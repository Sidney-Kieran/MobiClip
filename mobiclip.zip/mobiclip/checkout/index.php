<?php
session_start();
include "../functions/conn.php";
include "../functions/entities/product.php";
include "../functions/DAO/productDAO.php";
include "../functions/DAO/cartDAO.php";
include "../functions/entities/category.php";
include "../functions/DAO/categoryDAO.php";

if (!isset($_POST['productName'])){
    header("location:../");
}

if (!isset($_POST['qty'])){
    $total = $_REQUEST['price'];
    $qty = 1;
}else{
    $total = $_REQUEST['price']*$_REQUEST['qty'];
    $qty = $_REQUEST['qty'];
}
?>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>MOBICLIP | Checkout</title>
    <link rel="icon" href="../images/logo_small.png">
    <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Open+Sans" />
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include "../includes/header.php";?>
<main>
    <div class="container">
        <div><h3 class="text-center">SECURE!!! CHECKOUT WITH PAYPAL</h3></div>
        <div class="row cartProduct">
            <div class="col-sm-7 productLeft">
                <div class="">
                    <div class="col-sm-4 removeLeftPadding checkoutImg">
                        <img src="../admin_area/<?= $_REQUEST['image']?>" class="img-responsive">
                    </div>
                    <div class="col-sm-7">
                        <h2><?= $_REQUEST['productName'] ?></h2>
<!--                        <h4>--><?//= $_REQUEST['price'] ?><!--FCFA</h4>-->
                        <form action="../checkout/" method="POST">
                            <div class="form-group">
                                <label>Quatity</label>
                                <input type="number" name="qty" class="form-control" value="<?= $qty ?>" min="1" max="<?= $_REQUEST['maxQuantity']?>">
                                <input type="hidden" name="productID" value="<?= $_REQUEST['productID']?>">
                                <input type="hidden" name="productName" value="<?= $_REQUEST['productName']?>">
                                <input type="hidden" name="price" value="<?= $_REQUEST['price']?>">
                                <input type="hidden" name="image" value="<?= $_REQUEST['image']?>">
                            </div>
                            <div class="form-group">
                                <button class="buyBtn" type="submit">Add</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-sm-5">
                <div>
                    <h2 class="bottomLine">TOTAL</h2>
                    <h2><?= $total ?>FCFA</h2>
                </div>

<!--                paypal integration code-->
                <form action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="post">

                    <!-- Identify your business so that you can collect the payments. -->
                    <input type="hidden" name="business" value="admin@mobiclip.biz">

                    <!-- Specify a Buy Now button. -->
                    <input type="hidden" name="cmd" value="_xclick">

                    <!-- Specify details about the item that buyers will purchase. -->
                    <input type="hidden" name="item_name" value="<?= $_REQUEST['productName'] ?>">
                    <input type="hidden" name="amount" value="<?= $total ?>">
                    <input type="hidden" name="currency_code" value="USD">

                    <!-- specify where paypal should redirect after transaction is completed or cancelled-->
                    <input type="hidden" name="return" value="http://www.sidney.kilimanjarosystems.com/mobiclip/functions/order.php?qty=<?= $qty ?>&total=<?= $total ?>&product=<?= $_REQUEST['productID']?>">
                    <input type="hidden" name="return_cancel" value="http://www.sidney.kilimanjarosystems.com/mobiclip/cancel">

                    <!-- Display the payment button. -->
                    <input type="image" name="submit" border="0"
                           src="https://www.paypalobjects.com/en_US/i/btn/btn_buynow_LG.gif"
                           alt="PayPal - The safer, easier way to pay online">
                    <img alt="" border="0" width="1" height="1"
                         src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" >

                </form>
            </div>
        </div>
    </div>
</main>
<?php include "../includes/footer.php";?>
</body>
<script type="text/javascript" src="../js/jquery-3.1.0.min.js"></script>
<script type="text/javascript" src="../js/bootstrap.min.js"></script>
</html>
