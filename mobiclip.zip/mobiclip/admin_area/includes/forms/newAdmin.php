<main>
    <div class="actionHeading">
        <h4 class="text-center">Create Administrator</h4>
    </div>
    <div class="row addCategory">
        <div class="col s3">
            <!--                <div class="well"></div>-->
        </div>
        <div class="col s6">
            <?php if (isset($_GET['error'])):?>
                <div><?= $_GET['error']?></div>
            <?php endif;?>
            <form action="../../functions/formHandling/newadmin.php" method="post">
                <div>
                    <label>Name</label>
                    <input type="text" name="name" class="validate" placeholder="Please Enter Name of Admin">
                </div>
                <div>
                    <label>Email</label>
                    <input type="email" name="email" class="validate" placeholder="Please Enter Email of Admin">
                </div>
                <div>
                    <button type="submit" class="buyBtn">Create</button>
                </div>
            </form>
        </div>
        <div class="col s3">
            <!--                <div class="well"></div>-->
        </div>
    </div>
</main>