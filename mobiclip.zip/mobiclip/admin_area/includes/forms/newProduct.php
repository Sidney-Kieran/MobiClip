<?php
    include '../../functions/entities/brand.php';
    include '../../functions/DAO/brandDAO.php';
    include '../../functions/entities/category.php';
    include '../../functions/DAO/categoryDAO.php';

?>
<main>
    <div class="actionHeading">
        <h4 class="text-center">Create Product</h4>
    </div>
    <div class="row">
        <div class="col s4">
            <!--                <div class="well"></div>-->
        </div>
        <div class="col s4">
            <form action="../../functions/formHandling/newProduct.php" method="post" enctype="multipart/form-data">
                <div>
                    <?php if (isset($_GET['nameErr'])) :?>
                        <div><?= $_GET['nameErr']?></div>
                    <?php endif;?>
                    <label>Name</label>
                    <input type="text" name="name" class="validate" placeholder="Please Enter Name of Product">
                </div>
                <div>
                    <?php if (isset($_GET['colorErr'])) :?>
                        <div><?= $_GET['colorErr']?></div>
                    <?php endif;?>
                    <label>Color</label>
                    <input type="text" name="color" class="validate" placeholder="Please Enter Color of Product">
                </div>
                <div>
                    <?php if (isset($_GET['ramErr'])) :?>
                        <div><?= $_GET['ramErr']?></div>
                    <?php endif;?>
                    <label>RAM</label>
                    <input type="number" name="ram" class="validate" placeholder="Please Enter RAM Memory of Product">
                </div>
                <div>
                    <?php if (isset($_GET['processorErr'])) :?>
                        <div><?= $_GET['processorErr']?></div>
                    <?php endif;?>
                    <label>Processor</label>
                    <input type="text" name="processor" class="validate" placeholder="Please Enter Processor Specification">
                </div>
                <div>
                    <?php if (isset($_GET['priceErr'])) :?>
                        <div><?= $_GET['priceErr']?></div>
                    <?php endif;?>
                    <label>Unit Price</label>
                    <input type="number" name="price" class="validate" placeholder="Please Enter Unit Price(FCFA)">
                </div>
                <div>
                    <?php if (isset($_GET['priceErr'])) :?>
                        <div><?= $_GET['priceErr']?></div>
                    <?php endif;?>
                    <label>Quantity</label>
                    <input type="number" name="quantity" class="validate" placeholder="Please Enter Quantity in stock">
                </div>
                <div>
                    <label>Category</label>
                    <select name="category" id="">
                        <?php foreach(allCategories() as $category):?>
                            <option value=<?= $category->getCategoryID()?>><?= $category->getCategoryName()?></option>
                        <?php endforeach;?>
                    </select>
                </div>
                <div>
                    <label>Brand</label>
                    <select name="brand" id="">
                        <?php foreach(allBrands() as $brand):?>
                            <option value=<?= $brand->getBrandID()?>><?= $brand->getBrandName()?></option>
                        <?php endforeach;?>
                    </select>
                </div>
                <?php if (isset($_GET['pictureErr'])) :?>
                    <div><?= $_GET['pictureErr']?></div>
                <?php endif;?>
                <div class="file-field input-field">
                    <div class="btn">
                        <span>Picture</span>
                        <input type="file" name="picture" class="validate" placeholder="Please Enter Name of Category">
                    </div>
                    <div class="file-path-wrapper">
                        <input class="file-path validae"type="text">
                    </div>
                </div>
                <div>
                    <button type="submit" class="buyBtn">Create</button>
                </div>
            </form>
        </div>
        <div class="col s4">
        </div>
    </div>
</main>