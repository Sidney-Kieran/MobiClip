<main>
    <div class="actionHeading">
        <h4 class="text-center">Create Brand</h4>
    </div>
    <div class="row addCategory">
        <div class="col s3">
            <!--                <div class="well"></div>-->
        </div>
        <div class="col s6">
            <form action="../../functions/formHandling/newBrand.php" method="POST" enctype="multipart/form-data">
                <div>
                    <?php if (isset($_GET['nameErr'])) :?>
                        <div><?= $_GET['nameErr']?></div>
                    <?php endif;?>
                    <label>Name</label>
                    <input type="text" name="name" class="validate" placeholder="Please Enter Name of Brand">
                </div>
                <?php if (isset($_GET['uploadErr'])) :?>
                    <div><?= $_GET['uploadErr']?></div>
                <?php endif;?>
                <div class="file-field input-field">
                    <div class="btn">
                        <span>Logo</span>
                        <input type="file" name="logo" class="validate" placeholder="Please Enter Name of Category">
                    </div>
                    <div class="file-path-wrapper">
                        <input class="file-path validae"type="text">
                    </div>
                </div>
                <div>
                    <button type="submit" class="buyBtn">Create</button>
                </div>
            </form>
        </div>
        <div class="col s3">
            <!--                <div class="well"></div>-->
        </div>
    </div>
</main>