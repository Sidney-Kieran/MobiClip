<main>
    <div class="actionHeading">
        <h4 class="text-center">Create Category</h4>
    </div>
        <div class="row addCategory">
            <div class="col s3">
<!--                <div class="well"></div>-->
            </div>
            <div class="col s6">
                <form action="../../functions/formHandling/newCategory.php" method="post">
                    <div>
                        <label>Name</label>
                        <input type="text" name="name" class="validate" placeholder="Please Enter Name of Category">
                    </div>
                    <div>
                        <button type="submit" class="buyBtn">Create</button>
                    </div>
                </form>
            </div>
            <div class="col s3">
<!--                <div class="well"></div>-->
            </div>
        </div>
</main>