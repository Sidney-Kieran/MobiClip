<main>
    <div class="actionHeading">
        <h4 class="text-center">Customer List</h4>
    </div>
    <div class="row">
        <div class="col s1">
            <!--                <div class="well"></div>-->
        </div>
        <div class="col s10">
            <table class="responsive-table striped bordered">
                <thead>
                    <th>Customer ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Registration Date</th>
                </thead>
                <tbody>
                    <?php foreach(customerList() as $customer) :?>
                        <tr class="">
                            <td><?=$customer->getCustomerID()?></td>
                            <td><?=$customer->getCustomerName()?></td>
                            <td><?=$customer->getCustomerEmail()?></td>
                            <td><?=$customer->getRegDate()?></td>
                        </tr>
                    <?php endforeach;?>
                </tbody>

            </table>
        </div>
        <div class="col s1">
            <!--                <div class="well"></div>-->
        </div>
    </div>
</main>