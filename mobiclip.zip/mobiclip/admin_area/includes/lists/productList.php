<main>
    <div class="actionHeading">
        <h4 class="text-center">Product List</h4>
    </div>
    <div class="row">
<!--        <div class="col s1">-->
<!--            <!--                <div class="well"></div>-->
<!--        </div>-->
        <div class="col s12">
            <table class="responsive-table striped bordered">
                <thead>
                <th>Product ID</th>
                <th>Name</th>
                <th>Quantity</th>
                <th>RAM</th>
                <th>Processor</th>
                <th>Color</th>
                <th>Price</th>
                <th>Date Posted</th>
                </thead>
                <tbody>
                <?php foreach(productList() as $product) :?>
                    <tr class="">
                        <td><?=$product->getProductID()?></td>
                        <td><?=$product->getProductName()?></td>
                        <td><?=$product->getQuantity()?></td>
                        <td><?=$product->getRam()?>GB</td>
                        <td><?=$product->getProcessor()?></td>
                        <td><?=$product->getProductColor()?></td>
                        <td><?=$product->getPrice()?>FCFA</td>
                        <td><?=$product->getRegDate()?></td>
                    </tr>
                <?php endforeach;?>
                </tbody>

            </table>
        </div>
<!--        <div class="col s1">-->
<!--            <!--                <div class="well"></div>-->
<!--        </div>-->
    </div>
</main>