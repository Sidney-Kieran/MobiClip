<main>
    <div class="actionHeading">
        <h4 class="text-center">Admin List</h4>
    </div>
    <div class="row">
        <div class="col s1">
            <!--                <div class="well"></div>-->
        </div>
        <div class="col s10">
            <table class="responsive-table striped bordered">
                <thead>
                <th>Admin ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Registration Date</th>
                </thead>
                <tbody>
                <?php foreach(adminList() as $admin) :?>
                    <tr class="">
                        <td><?=$admin->getAdminID()?></td>
                        <td><?=$admin->getAdminName()?></td>
                        <td><?=$admin->getAdminEmail()?></td>
                        <td><?=$admin->getRegDate()?></td>
                    </tr>
                <?php endforeach;?>
                </tbody>

            </table>
        </div>
        <div class="col s1">
            <!--                <div class="well"></div>-->
        </div>
    </div>
</main>