<?php session_start();
    if (!isset($_SESSION['mobiclip_ID'])){
        header("location:../../");
    }
    include '../../functions/conn.php';
    include '../../functions/entities/product.php';
    include '../../functions/DAO/productDAO.php';
    include '../../functions/entities/customer.php';
    include '../../functions/DAO/customerDAO.php';
include '../../functions/entities/admin.php';
include '../../functions/DAO/adminDAO.php';
?>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>MOBICLIP | Admin Panel</title>
    <link rel="icon" href="../../images/logo_small.png">
    <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Open+Sans" />
    <link rel="stylesheet" href="../css/materialize.min.css">
<!--    <link rel="stylesheet" href="../../css/bootstrap.min.css">-->
    <style>
        body{
            font-family: "open sans";
        }
        header, main, footer {
            padding-left: 300px;
        }

        @media only screen and (max-width : 992px) {
            header, main, footer {
                padding-left: 0;
            }
        }
        .actionHeading{
            padding: 5px;
            background-color: #dddddd;
            margin-top: -22px;
            margin-bottom: 20px;
            color: #292929;
            text-align: center;
        }
        .buyBtn {
            display: inline-block;
            outline: none;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
            font: 14px/100% Arial, Helvetica, sans-serif;
            padding: .5em 2em .55em;
            text-shadow: 0 1px 1px rgba(0,0,0,.3);
            -webkit-border-radius: .5em;
            -moz-border-radius: .5em;
            border-radius: .5em;
            -webkit-box-shadow: 0 1px 2px rgba(0,0,0,.2);
            -moz-box-shadow: 0 1px 2px rgba(0,0,0,.2);
            box-shadow: 0 1px 2px rgba(0,0,0,.2);
            color: #fef4e9;
            border: solid 1px #da7c0c;
            background: #f78d1d;
            background: -webkit-gradient(linear, left top, left bottom, from(#faa51a), to(#f47a20));
            background: -moz-linear-gradient(top,  #faa51a,  #f47a20);
            filter:  progid:DXImageTransform.Microsoft.gradient(startColorstr='#faa51a', endColorstr='#f47a20');
        }
        .buyBtn:hover {
            text-decoration: none;
        }
        .buyBtn:active {
            position: relative;
            top: 1px;
        }
        .addCategory{
            padding-top: 200px;
        }
        input:focus{
            border-bottom: 1px solid #f78d1d!important;
            box-shadow: 0 1px 0 0 #f78d1d!important;
        }
        label{
            font-size: large;
            color: #292929;
        }
        .dropdown-content li>a, .dropdown-content li>span {
            color: #292929;
        }
        .userView{
            background-image: url("../../images/back.jpg");
        }
    </style>
</head>
<body>

    <ul id="slide-out" class="side-nav fixed">
        <li><div class="userView">
                <a href="#!user"><img  src="../../images/user.png" class="responsive-img"></a>
                <div class="center">
                    <span class="name"> <?php echo $_SESSION['mobiclip_name'];?></span>
                </div>


        <li><a  class="waves-effect" href="?action=newBrand">New Brand</a></li>
        <li><div class="divider"></div></li>
        <li><a  class="waves-effect" href="?action=newCategory">New Category</a></li>
        <li><div class="divider"></div></li>
        <li><a class="waves-effect" href="?action=newProduct">New Product</a></li>
        <li><div class="divider"></div></li>
        <li><a class="waves-effect" href="?action=newAdmin">New Admin</a></li>
        <li><div class="divider"></div></li>
        <li><a class="waves-effect" href="?action=productList">Product List</a></li>
        <li><div class="divider"></div></li>
        <li><a class="waves-effect" href="?action=adminList">Admin List</a></li>
        <li><div class="divider"></div></li>
        <li><a class="waves-effect" href="?action=customerList">Customer List</a></li>
        <li><div class="divider"></div></li>
        <li><a class="waves-effect" href="../../">Back To Home</a></li>
        <li><div class="divider"></div></li>
    </ul>
    <a href="#" data-activates="slide-out" class="button-collapse"><i class="material-icons">menu</i></a>


        <?php
            if (isset($_GET['action'])){
                $action = $_GET['action'];
                if ($action == "newBrand"){
                    include "../includes/forms/newBrand.php";
                }elseif ($action == "newCategory"){
                    include "../includes/forms/newCategory.php";
                }elseif ($action == "newAdmin"){
                    include "../includes/forms/newAdmin.php";
                }elseif ($action == "newProduct"){
                    include "../includes/forms/newProduct.php";
                }elseif ($action == "productList"){
                    include "../includes/lists/productList.php";
                }elseif ($action == "adminList"){
                    include "../includes/lists/adminList.php";
                }elseif ($action == "customerList"){
                    include "../includes/lists/customerList.php";
                }
            }
        ?>
    <footer>

    </footer>
</body>
<script type="text/javascript" src="../../js/jquery-3.1.0.min.js"></script>
<script type="text/javascript" src="../js/materialize.min.js"></script>
<script>
    $(".button-collapse").sideNav();
    $(document).ready(function () {
        $('select').material_select();
    });
</script>
</html>