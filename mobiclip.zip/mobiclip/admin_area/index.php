<?php
session_start();
if (isset($_SESSION['mobiclip_ID'])){
    header("location:home");

}
?>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>MOBICLIP | Admin Login</title>
    <link rel="icon" href="../images/logo_small.png">
    <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Open+Sans" />
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="styles/style.css">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="container" id="theMain">
        <div class="col-sm-8 adminSide">
            <img src="../images/logo.png" alt="mobiclip logo" class="img-responsive">
            <h4 class="text-center">This section of the system is for authorised personnel only. Please <strong><a href="#">LEAVE</a></strong> if you are not</h4>
        </div>
        <div class="col-sm-4 theForm">
            <?php if (isset($_GET['error'])):?>
                <div class="text-center text-danger"><?= $_GET['error']?></div>
            <?php endif;?>
            <div class="">
                <form action="../functions/formHandling/login.php?source=admin" method="post">
                    <div class="form-group">
                        <label>E-Mail</label>
                        <input type="email" name="email" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" name="password" class="form-control">
                    </div>
                    <div class="form-group">
                       <button type="submit" class="btn-block buyBtn">Login</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
<script type="text/javascript" src="../js/jquery-3.1.0.min.js"></script>
<script type="text/javascript" src="../js/bootstrap.min.js"></script>
</html>